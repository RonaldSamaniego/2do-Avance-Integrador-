/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.proyectotextilprofitex;

import Vistas.FrmLogin;

/**
 *
 * @author fperez
 */
public class ProyectoTextilProfitex {

    public static void main(String[] args) {
        FrmLogin login = new FrmLogin();
        login.setVisible(true);
    }
}
