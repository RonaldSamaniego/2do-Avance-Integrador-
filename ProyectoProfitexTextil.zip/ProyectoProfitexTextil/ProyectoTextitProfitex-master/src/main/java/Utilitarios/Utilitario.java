/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilitarios;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 *
 * @author XECURE01
 */
public class Utilitario {
    
      public boolean isValid(String dateStr) {
        DateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        sdf.setLenient(false);
        try {
            sdf.parse(dateStr);
        } catch (ParseException e) {
            return false;
        }
        return true;
    }
    public int hex( String color_hex )
    {
        return Integer.parseInt(color_hex,  16 );
    }
      public Date StringADate(String fecha){
       SimpleDateFormat formato_del_Texto = new SimpleDateFormat("dd-MM-yyyy");
       Date fechaE=null;
       try {
       fechaE = formato_del_Texto.parse(fecha);
        return fechaE;
        } catch (ParseException ex) {
       return null;
      }
     }
      
      
      public String RetornFormatofecha( String fecha)
      {
                
           SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");        
          return sdf.format(fecha);
      }
      
      public Double RedondearDosDecimales(Double valor)
      {
          return  Math.round(valor * 100.0)/100.0;
      }
    public static boolean validarFecha(Date fecha) {
        try {
            SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
            formatoFecha.setLenient(false);
        
           // formatoFecha(fecha.toString());
        } catch (Exception e) {
            return false;
        }
        return true;
    }
      public static boolean validarEntreFechas(Date fecha1,Date fecha2) {
        try {
            SimpleDateFormat formatoFecha = new SimpleDateFormat("dd/MM/yyyy");
            formatoFecha.setLenient(false);
            Date fec1= fecha1;
             Date fec2= (fecha2);
             if(fec1.after(fec2) )
             {
                     return false;
             }
          
        } catch (Exception e) {
            return false;
        }
        return true;
    }
}
