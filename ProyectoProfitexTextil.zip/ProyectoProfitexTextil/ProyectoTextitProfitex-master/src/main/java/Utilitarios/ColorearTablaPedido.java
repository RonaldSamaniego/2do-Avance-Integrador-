/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilitarios;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author XECURE01
 */
public class ColorearTablaPedido extends DefaultTableCellRenderer{
    private Component componente;
    

    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        componente = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        Font font = new Font("Tahoma", Font.BOLD, 11);
        if(table.getValueAt(row, 3).toString().equals("PENDIENTE")){
            this.setForeground(Color.gray);
            componente.setFont(font);
        }
        else if(table.getValueAt(row, 3).toString().equals("EN PROCESO")) {
            this.setForeground(Color.ORANGE);
        } 
         else if(table.getValueAt(row, 3).toString().equals("CULMINADO")) {
            this.setForeground(Color.GREEN);
        } 
          else if(table.getValueAt(row, 3).toString().equals("ENTREGADO")) {
            this.setForeground(Color.blue);
        } 
        else {
              this.setForeground(Color.black);
        }
        return this;
    }   
}
