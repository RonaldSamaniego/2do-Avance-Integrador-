/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilitarios;

import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JTable;
import javax.swing.table.DefaultTableCellRenderer;

/**
 *
 * @author XECURE01
 */
public class ColorearTabla extends DefaultTableCellRenderer{
    
    private Component componente;
    

    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
        componente = super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
        Font font = new Font("Tahoma", Font.BOLD, 11);
        if(table.getValueAt(row, 3).toString().equals("Ocupado")){
            this.setForeground(Color.red);
            componente.setFont(font);
        }
        else if(table.getValueAt(row, 3).toString().equals("Libre")) {
            this.setForeground(Color.green);
        } 
        else {
              this.setForeground(Color.black);
        }
        return this;
    }    
    
}