
package Modelo;


public class ModeloProducto {
      private int IdModelo;    
      private String Nombre;
      private int Estado;

    public ModeloProducto(int id, String nombre,int estado) {
        this.IdModelo = id;     
        this.Nombre = nombre;        
        this.Estado=estado;
    }

    public ModeloProducto() {
    }

    public int getIdModelo() {
        return IdModelo;
    }

    public void setIdModelo(int id) {
        this.IdModelo = id;
    }
  

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String nombre) {
        this.Nombre = nombre;
    }

    

   
  public int getEstado() {
        return Estado;
    }

    public void setEstado(int estado) {
        this.Estado = estado;
    }
}
