
package Modelo;


public class Pedido {
    private int IdPedido;   
   private String Descripcion;
    private int IdCliente;
    private String Cliente;
    private String Fecha;
    private String FechDevolucion;
    private String TotalGeneral;   
    private  int IdUsuario;
    private int Estado;
  private String EstadoNombre;
    public Pedido(int idpedido,String descripcion,int idcliente,String cliente, String fecha, String fechadevolucion,String total ,int idusuario, int estado,String estadonombre) {
        this.IdPedido = idpedido;
      
        this.Descripcion=descripcion;
        this.IdCliente = idcliente;
        this.Cliente=cliente;
        this.Fecha = fecha;
        this.FechDevolucion =fechadevolucion;
        this.TotalGeneral =total;   
        this.IdUsuario=idusuario;
        this.Estado=estado;
        this.EstadoNombre=estadonombre;
    }

    public Pedido() {
    }
     public int getIdPedido() {
        return IdPedido;
    }

    public void setIdPedido(int id) {
        this.IdPedido = id;
    }
    
    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.Descripcion = descripcion;
    }
    public int getIdCliente() {
        return IdCliente;
    }

    public void setIdCliente(int id) {
        this.IdCliente = id;
    }
   public String getCliente() {
        return Cliente;
    }

    public void setCliente(String id) {
        this.Cliente = id;
    }
    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String usuario) {
        this.Fecha = usuario;
    }

    public String getFechaDevolucion() {
        return FechDevolucion;
    }

    public void setFechaDevolucion(String fechadevol) {
        this.FechDevolucion = fechadevol;
    }

    public String getTotalGeneral() {
        return TotalGeneral;
    }

    public void setTotalGeneral(String total) {
        this.TotalGeneral = total;
    }

 
      public int getIdUsuario() {
        return IdUsuario;
    }

    public void setIdUsuario(int idusuario) {
        this.IdUsuario = idusuario;
    }
  public int getEstado() {
        return Estado;
    }

    public void setEstado(int estado) {
        this.Estado = estado;
    }
     public String getEstadoNombre() {
        return EstadoNombre;
    }

    public void setEstadoNombre(String estado) {
        this.EstadoNombre = estado;
    }

}
