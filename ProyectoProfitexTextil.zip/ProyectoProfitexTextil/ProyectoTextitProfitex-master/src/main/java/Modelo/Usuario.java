
package Modelo;


public class Usuario {
        private int IdUsuario;
    private String usuario;
    private String nombres;
    private String correo;
    private String clave;
      private int Estado;

    public Usuario(int id, String usuario, String nombre, String correo, String clave, int estado) {
        this.IdUsuario = id;
        this.usuario = usuario;
        this.nombres = nombre;
        this.correo = correo;
        this.clave = clave;
        this.Estado=estado;
    }

    public Usuario() {
    }

    public int getIdUsuario() {
        return IdUsuario;
    }

    public void setIdUsuario(int id) {
        this.IdUsuario = id;
    }

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombre) {
        this.nombres = nombre;
    }

    public String getCorreo() {
        return correo;
    }

    public void setCorreo(String correo) {
        this.correo = correo;
    }

    public String getClave() {
        return clave;
    }

    public void setClave(String clave) {
        this.clave = clave;
    }
  public int getEstado() {
        return Estado;
    }

    public void setEstado(int estado) {
        this.Estado = estado;
    }

    
}
