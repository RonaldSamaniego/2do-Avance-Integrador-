
package Modelo;


public class Producto {
     int IdProducto;
     private int IdModelo;
   private String Modelo;
    String Descripcion;    
     
    String Precio;
    double PrecioFabricacion;
    double PrecioElaboracionDestajero;
    String Stock;
    
    int IdUsuario;
    int Estado;

    public Producto() {
    }

    public Producto(int id, int idmodelo,String modelo,String nombres,String stock, String precio,double PrecioFabricacion,double precioElaboracionDestajero, int idusuario,int estado) {
        this.IdProducto = id;
         this.IdModelo=idmodelo;
        this.Modelo=modelo;
        this.Descripcion = nombres;       
        this.Stock = stock;
        this.Precio = precio;
        this.PrecioFabricacion=PrecioFabricacion;
        this.PrecioElaboracionDestajero=precioElaboracionDestajero;
        this.IdUsuario=idusuario;
          this.Estado=estado;
    }

    public int getIdProducto() {
        return IdProducto;
    }

    public void setIdProducto(int id) {
        this.IdProducto = id;
    }
   public int getIdModelo() {
        return IdModelo;
    }

    public void setIdModelo(int id) {
        this.IdModelo = id;
    }
    public String getModelo() {
        return Modelo;
    }

    public void setModelo(String mod) {
        this.Modelo = mod;
    }
    public String getDescripcion() {
        return Descripcion;
    }

    public void setDescripcion(String nombres) {
        this.Descripcion = nombres;
    }

   
   

    public String getPrecio() {
        return Precio;
    }

    public void setPrecio(String precio) {
        this.Precio = precio;
    }
 public double getPrecioFabricacion() {
        return PrecioFabricacion;
    }

    public void setPrecioFabricacion(double precio) {
        this.PrecioFabricacion = precio;
    }
     public double getPrecioElaboracionDestajero() {
        return PrecioElaboracionDestajero;
    }

    public void setPrecioElaboracionDestajero(double precio) {
        this.PrecioElaboracionDestajero = precio;
    }
    public String getStock() {
        return Stock;
    }

    public void setStock(String stock) {
        this.Stock = stock;
    }
         public int getIdUsuario() {
        return IdUsuario;
    }

    public void setIdUsuario(int idusuario) {
        this.IdUsuario = idusuario;
    }
  public int getEstado() {
        return Estado;
    }

    public void setEstado(int estado) {
        this.Estado = estado;
    }
}
