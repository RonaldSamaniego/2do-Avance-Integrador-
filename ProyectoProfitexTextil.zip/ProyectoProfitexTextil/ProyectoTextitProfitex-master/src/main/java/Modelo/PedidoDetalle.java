
package Modelo;


public class PedidoDetalle {
        private int IdPedido;
    private int IdProducto;
    private String Producto;
    private String Cantidad;
    private String Precio;
    private String Total;
       public PedidoDetalle(int idpedido,int idproducto,String producto,String cantidad, String precio,String total) {
        this.IdPedido = idpedido;
        this.IdProducto=idproducto;
        this.Producto = producto;
        this.Cantidad=cantidad;
        this.Precio = precio;
        this.Total =total;    
    }

    public PedidoDetalle() {
    }
     public int getIdPedido() {
        return IdPedido;
    }

    public void setIdPedido(int id) {
        this.IdPedido = id;
    }
    
     public int getIdProducto() {
        return IdProducto;
    }

    public void setIdProducto(int id) {
        this.IdProducto = id;
    }
    public String getProducto() {
        return Producto;
    }

    public void setProducto(String id) {
        this.Producto = id;
    }
   public String getCantidad() {
        return Cantidad;
    }

    public void setCantidad(String id) {
        this.Cantidad = id;
    }
    public String getPrecio() {
        return Precio;
    }

    public void setPrecio(String precio) {
        this.Precio = precio;
    }

    public String getTotal() {
        return Total;
    }

    public void setTotal(String total) {
        this.Total = total;
    }

   
}
