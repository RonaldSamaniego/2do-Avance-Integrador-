
package Modelo;


public class ServicioDestajeroDetalle {
        private int IdServicio;
    private int IdProducto;
    private String Producto;
       private String CostoPrenda;
    private String Cantidad;
    private String CantidadEntregada;
    private String Precio;
    private String SubTotal;
    private String Descuento;
    private String Total;
    private String TotalPagar;
       public ServicioDestajeroDetalle(int idservicio,int idproducto,String producto,String costoprenda,String cantidad,String cantidadentregada, String precio,String subtotal,String descuento,String total,String totalpagar) {
        this.IdServicio = idservicio;
        this.IdProducto=idproducto;
        this.Producto = producto;
        this.CostoPrenda=costoprenda;
        this.Cantidad=cantidad;
        this.CantidadEntregada=cantidadentregada;
        this.Precio = precio;
        this.SubTotal=subtotal;
        this.Descuento=descuento;
        this.Total =total;    
        this.TotalPagar=totalpagar;
    }

    public ServicioDestajeroDetalle() {
    }
     public int getIdServicio() {
        return IdServicio;
    }

    public void setIdServicio(int id) {
        this.IdServicio = id;
    }
    
     public int getIdProducto() {
        return IdProducto;
    }

    public void setIdProducto(int id) {
        this.IdProducto = id;
    }
    public String getProducto() {
        return Producto;
    }

    public void setProducto(String id) {
        this.Producto = id;
    }
    public String getCostoPrenda() {
        return CostoPrenda;
    }

    public void setCostoPrenda(String id) {
        this.CostoPrenda = id;
    }
   public String getCantidad() {
        return Cantidad;
    }

    public void setCantidad(String id) {
        this.Cantidad = id;
    }
      public String getCantidadEntregada() {
        return CantidadEntregada;
    }

    public void setCantidadEntregada(String id) {
        this.CantidadEntregada= id;
    }
    public String getPrecio() {
        return Precio;
    }

    public void setPrecio(String precio) {
        this.Precio = precio;
    }
     public String getSubtotal() {
        return SubTotal;
    }

    public void setSubtotal(String precio) {
        this.SubTotal = precio;
    }
     public String getDescuento() {
        return Descuento;
    }

    public void setDescuento(String descuento) {
        this.Descuento = descuento;
    }
    
    public String getTotal() {
        return Total;
    }

    public void setTotal(String total) {
        this.Total = total;
    }
    
    public String getTotalPagar() {
        return TotalPagar;
    }

    public void setTotalPagar(String total) {
        this.TotalPagar = total;
    }
}
