
package Modelo;


public class ServicioDestajero {
       private int IdServicioDestajero;      
    private int IdPedido;
      private String Pedido;
    private int IdDestajero;
    private String Destajero;
    private String Cliente;
    private String Fecha;
    private String FechDevolucion;
    private String TotalGeneral;   
      private String Descuento;   
    private String TotalPagar;   
    private String CantidadTotalEntregado;   
    private String CantidadTotalCulminado;   
    private  int IdUsuario;
    private int Estado;
  private String EstadoNombre;
    public ServicioDestajero(int idserviciodestajero,int idpedido,String pedido,int iddestajero,String destajero,String fecha, String fechadevolucion,String total,String totalpagar,String cantidadtotalEntregado,String cantidadtotalCulminado ,int idusuario, int estado,String estadonombre,String descuento) {
        this.IdServicioDestajero = idserviciodestajero;
        this.IdPedido=idpedido;
        this.Pedido=pedido;
        this.IdDestajero = iddestajero;
        this.Destajero=destajero;
        this.Fecha = fecha;
        this.FechDevolucion =fechadevolucion;
        this.TotalGeneral =total;   
        this.TotalPagar =totalpagar;  
        this.CantidadTotalEntregado=cantidadtotalEntregado;
        this.CantidadTotalCulminado=cantidadtotalCulminado;
        this.IdUsuario=idusuario;
        this.Estado=estado;
        this.EstadoNombre=estadonombre;
        this.Descuento=descuento;
    }

    public ServicioDestajero() {
    }
    
     public int getIdServicioDestajero() {
        return IdServicioDestajero;
    }

    public void setIdServicioDestajero(int id) {
        this.IdServicioDestajero = id;
    }
    
     public int getIdPedido() {
        return IdPedido;
    }

    public void setIdPedido(int id) {
        this.IdPedido = id;
    }
       
     public String getPedido() {
        return Pedido;
    }

    public void setIPedido(String ped) {
        this.Pedido = ped;
    }
     public int getIdDestajero() {
        return IdDestajero;
    }

    public void setIdDestajero(int id) {
        this.IdDestajero = id;
    }
    public String getDestajero() {
        return Destajero;
    }

    public void setDestajero(String des) {
        this.Destajero = des;
    }
    public String getFecha() {
        return Fecha;
    }

    public void setFecha(String usuario) {
        this.Fecha = usuario;
    }

    public String getFechaDevolucion() {
        return FechDevolucion;
    }

    public void setFechaDevolucion(String fechadevol) {
        this.FechDevolucion = fechadevol;
    }

    public String getTotalGeneral() {
        return TotalGeneral;
    }

    public void setTotalGeneral(String total) {
        this.TotalGeneral = total;
    }
    public String getTotalPagar() {
        return TotalPagar;
    }

    public void setTotalPagar(String total) {
        this.TotalPagar = total;
    }
     public String getCantidadTotalEntregado() {
        return CantidadTotalEntregado;
    }

    public void setCantidadTotalEntregado(String total) {
        this.CantidadTotalEntregado = total;
    }
     public String getCantidadTotalCulminado() {
        return CantidadTotalCulminado;
    }

    public void setCantidadTotalCulminado(String total) {
        this.CantidadTotalCulminado = total;
    }
    public int getIdUsuario() {
        return IdUsuario;
    }

    public void setIdUsuario(int idusuario) {
        this.IdUsuario = idusuario;
    }
  public int getEstado() {
        return Estado;
    }

    public void setEstado(int estado) {
        this.Estado = estado;
    }
     public String getEstadoNombre() {
        return EstadoNombre;
    }

    public void setEstadoNombre(String estado) {
        this.EstadoNombre = estado;
    }
  public String getDescuento() {
        return Descuento;
    }

    public void setDescuento(String desc) {
        this.Descuento = desc;
    }
}
