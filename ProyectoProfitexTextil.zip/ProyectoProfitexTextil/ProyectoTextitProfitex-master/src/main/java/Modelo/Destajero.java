
package Modelo;


public class Destajero {
      private int IdDestajero;
    private String Ruc;
    private String RazonSocial;
    private String Direccion;
    private String Telefono;
    private String RepresentanteLegal;
    private  int IdUsuario;
    private int Estado;
    private String EstadoNombre;

    public Destajero(int id, String ruc, String razonsocial,String direccion , String telefono, String representantelegal,int idusuario, int estado,String estadonombre) {
        this.IdDestajero = id;
        this.Ruc = ruc;
        this.RazonSocial =razonsocial;
        this.Direccion =direccion;
        this.Telefono = telefono;
        this.RepresentanteLegal=representantelegal;
        this.IdUsuario=idusuario;
        this.Estado=estado;
        this.EstadoNombre=estadonombre;
    }

    public Destajero() {
    }

    public int getIdDestajero() {
        return IdDestajero;
    }

    public void setIdDestajero(int id) {
        this.IdDestajero = id;
    }

    public String getRuc() {
        return Ruc;
    }

    public void setRuc(String usuario) {
        this.Ruc = usuario;
    }

    public String getRazonSocial() {
        return RazonSocial;
    }

    public void setRazonSocial(String nombre) {
        this.RazonSocial = nombre;
    }

    public String getDireccion() {
        return Direccion;
    }

    public void setDireccion(String direccion) {
        this.Direccion = direccion;
    }

    public String getTelefono() {
        return Telefono;
    }

    public void setTelefono(String telefono) {
        this.Telefono = telefono;
    }
      public String getRepresentanteLegal() {
        return RepresentanteLegal;
    }

    public void setRepresentanteLegal(String representantelegal) {
        this.RepresentanteLegal = representantelegal;
    }
      public int getIdUsuario() {
        return IdUsuario;
    }

    public void setIdUsuario(int idusuario) {
        this.IdUsuario = idusuario;
    }
  public int getEstado() {
        return Estado;
    }

    public void setEstado(int estado) {
        this.Estado = estado;
    }
    public String getEstadoNombre() {
        return EstadoNombre;
    }

    public void setEstadoNombre(String estado) {
        this.EstadoNombre = estado;
    }

}
