
package DAO;

import Configuracion.Conexion;
import Modelo.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class UsuarioDao {
    
      Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    
     public boolean registrar(Usuario us) {
        String sql = "INSERT INTO usuario (usuario, nombres,clave,estado) VALUES (?,?,?,?)";
        con = cn.getConnection();
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, us.getUsuario());
            ps.setString(2, us.getNombres());    
            ps.setString(3, us.getClave());
            ps.setInt(4, us.getEstado());
            ps.execute();
            return true;
        } catch (SQLException ex) {
            System.out.println(ex.toString());
            return false;
        }
    }

    public boolean actualizar(Usuario reg) {
        boolean res;
        String sql = "UPDATE usuario SET usuario=?, nombres=?,clave=?,estado=? WHERE idusuario = ?";
        con = cn.getConnection();
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, reg.getUsuario());
            ps.setString(2, reg.getNombres());
            ps.setString(3, reg.getClave());
             ps.setInt(4, reg.getEstado());
            ps.setInt(5, reg.getIdUsuario());
            ps.execute();
            res = true;
        } catch (SQLException ex) {
            System.out.println(ex.toString());
            res = false;
        }
        return res;
    }
      public List Listar(String valor) {
        List<Usuario> lista = new ArrayList();
        try {
            con = cn.getConnection();
            if ("".equalsIgnoreCase(valor)) {
                String sql = "SELECT * FROM usuario ORDER BY IdUsuario DESC";
                ps = con.prepareStatement(sql);
            } else {
                String sql = "SELECT * FROM usuario WHERE nombres LIKE '%" + valor + "%' OR usuario LIKE '%" + valor + "%'";
                ps = con.prepareStatement(sql);
            }
            rs = ps.executeQuery();
            while (rs.next()) {
                Usuario user = new Usuario();
                user.setIdUsuario(rs.getInt("idusuario"));
                user.setUsuario(rs.getString("usuario"));
                user.setNombres(rs.getString("nombres"));  
                user.setClave(rs.getString("clave"));  
                user.setEstado(rs.getInt("estado"));  
                lista.add(user);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return lista;
    }
    public Usuario login(String user, String pass) {
        String sql = "SELECT * FROM usuario WHERE usuario = ? AND clave = ?";
        Usuario l = new Usuario();
        try {
            con = cn.getConnection();
            ps = con.prepareStatement(sql);
            ps.setString(1, user);
            ps.setString(2, pass);
            rs = ps.executeQuery();
            if (rs.next()) {
                if (rs.getRow() > 0) {
                    l.setIdUsuario(rs.getInt("IdUsuario"));
                    l.setUsuario(rs.getString("usuario"));
                    l.setNombres(rs.getString("nombres"));
                }
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return l;
    }
}
