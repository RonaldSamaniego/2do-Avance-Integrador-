
package DAO;

import Configuracion.Conexion;
import Modelo.Producto;
import Modelo.ModeloProducto;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ModeloProductoDAO {
            Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    
     public List ListarAyuda(String valor) {
        List<ModeloProducto> lista = new ArrayList();
        try {
            con = cn.getConnection();
            if ("".equalsIgnoreCase(valor)) {
                String sql = "SELECT * FROM Modelo where estado=1 ORDER BY IdModelo DESC";
                ps = con.prepareStatement(sql);
            } else {
                String sql = "SELECT * FROM Modelo WHERE nombre LIKE '%" + valor + "%' and estado=1";
                ps = con.prepareStatement(sql);
            }
            rs = ps.executeQuery();
            while (rs.next()) {
                ModeloProducto user = new ModeloProducto();
                user.setIdModelo(rs.getInt("IdModelo"));
                user.setNombre(rs.getString("nombre"));                 
                user.setEstado(rs.getInt("estado"));  
                lista.add(user);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return lista;
    }
}
