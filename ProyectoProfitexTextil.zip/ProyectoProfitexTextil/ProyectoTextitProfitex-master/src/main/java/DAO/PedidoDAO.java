
package DAO;

import Configuracion.Conexion;
import Modelo.Cliente;
import Modelo.Pedido;
import Modelo.PedidoDetalle;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.util.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import javax.accessibility.AccessibleRole;
import javax.swing.JOptionPane;


public class PedidoDAO {
       Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;
     public List Listar(String valor) {
        List<Pedido> lista = new ArrayList();
        try {
            con = cn.getConnection();
            if ("".equalsIgnoreCase(valor)) {
                String sql = "SELECT  p.IdPedido,p.Comentario,c.IdCliente,c.RazonSocial as Cliente,p.fecha,p.fechaDevolucion,p.TotalGeneral ,p.Estado FROM Pedido p inner join cliente c on p.IdCliente=c.IdCliente ORDER BY p.IdPedido DESC";
                ps = con.prepareStatement(sql);
            } else {
                String sql = "SELECT  p.IdPedido,p.Comentario,c.IdCliente,c.RazonSocial as Cliente,p.fecha,p.fechaDevolucion,p.TotalGeneral ,p.Estado FROM Pedido p inner join cliente c on p.IdCliente=c.IdCliente WHERE  c.razonsocial LIKE '%" + valor + "%'";
                ps = con.prepareStatement(sql);
            }
            rs = ps.executeQuery();
            while (rs.next()) {
                Pedido user = new Pedido();
                user.setIdPedido(rs.getInt("IdPedido"));
                user.setDescripcion(rs.getString("Comentario"));  
                user.setIdCliente(rs.getInt("IdCliente"));
                user.setCliente(rs.getString("Cliente"));
                user.setFecha(rs.getString("fecha"));  
                user.setFechaDevolucion(rs.getString("fechaDevolucion")); 
                 user.setTotalGeneral(rs.getString("TotalGeneral"));          
                user.setEstado(rs.getInt("estado"));  
                lista.add(user);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return lista;
    }
      public List ListarAyudaPedido(String valor) {
        List<Pedido> lista = new ArrayList();
        try {
            con = cn.getConnection();
            if ("".equalsIgnoreCase(valor)) {
                String sql = "select p.IdPedido,p.Comentario,c.IdCliente,c.RazonSocial as Cliente,p.Estado, case when p.Estado=1 then 'PENDIENTE' when p.estado=2 THEN 'EN PROCESO' WHEN P.Estado=3 THEN 'CULMINADO' WHEN P.Estado=4 THEN 'ENTREGADO' END AS EstadoNombre FROM Pedido p inner join cliente c on p.IdCliente=c.IdCliente where p.estado<>0 ORDER BY p.IdPedido DESC";
                ps = con.prepareStatement(sql);
            } else {
                String sql = "select p.IdPedido,p.Comentario,c.IdCliente,c.RazonSocial as Cliente,p.Estado, case when p.Estado=1 then 'PENDIENTE' when p.estado=2 THEN 'EN PROCESO' WHEN P.Estado=3 THEN 'CULMINADO' WHEN P.Estado=4 THEN 'ENTREGADO' END AS EstadoNombre FROM Pedido p inner join cliente c on p.IdCliente=c.IdCliente WHERE p.estado<>0 and   c.razonsocial LIKE '%" + valor + "%'";
                ps = con.prepareStatement(sql);
            }
            rs = ps.executeQuery();
            while (rs.next()) {
                Pedido user = new Pedido();
                user.setIdPedido(rs.getInt("IdPedido"));
                user.setDescripcion(rs.getString("Comentario"));                
                user.setCliente(rs.getString("Cliente"));                      
                user.setEstado(rs.getInt("estado"));  
                user.setEstadoNombre(rs.getString("EstadoNombre"));  
                lista.add(user);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return lista;
    }
       public List ListarPedidoProducto(String valor) {
        List<PedidoDetalle> lista = new ArrayList();
        try {
            con = cn.getConnection();
           
             String sql = "SELECT p.IdPedido,m.Nombre as ProductoNombre,p.Cantidad,p.precio,p.Total FROM pedidodetalle p inner JOIN producto pr on p.IdProducto=pr.IdProducto inner join modelo m on  pr.idmodelo=m.idmodelo WHERE  p.idpedido = '" + valor + "'";
                ps = con.prepareStatement(sql);
           
            rs = ps.executeQuery();
            while (rs.next()) {
                PedidoDetalle user = new PedidoDetalle();
                user.setIdPedido(rs.getInt("IdPedido"));
                user.setProducto(rs.getString("ProductoNombre"));
                user.setCantidad(rs.getString("Cantidad"));
                user.setPrecio(rs.getString("Precio"));
                user.setTotal(rs.getString("Total")); 
                
                lista.add(user);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return lista;
    }
       
        public List ObtenerPedidoProducto(String valor) {
        List<PedidoDetalle> lista = new ArrayList();
        try {
            con = cn.getConnection();
           
             String sql = "SELECT p.IdPedido,pr.IdProducto ,m.Nombre as ProductoNombre,p.Cantidad,pr.PrecioElaboracionDestajero,p.cantidad * pr.PrecioElaboracionDestajero as Total FROM pedidodetalle p inner JOIN producto pr on p.IdProducto=pr.IdProducto inner join modelo m on pr.idmodelo=m.idmodelo WHERE  p.idpedido = '" + valor + "'";
                ps = con.prepareStatement(sql);
           
            rs = ps.executeQuery();
            while (rs.next()) {
                PedidoDetalle user = new PedidoDetalle();
                user.setIdPedido(rs.getInt("IdPedido"));
                user.setIdProducto(rs.getInt("IdProducto"));
                user.setProducto(rs.getString("ProductoNombre"));
                user.setCantidad(rs.getString("Cantidad"));
                user.setPrecio(rs.getString("PrecioElaboracionDestajero"));
                user.setTotal(rs.getString("Total")); 
                
                lista.add(user);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return lista;
    }
       public boolean registrarPedido(Pedido us) {
        String sql = "INSERT INTO pedido (Comentario,IdCliente,Fecha,FechaDevolucion,TotalGeneral,IdUsuarioRegistro,estado) VALUES (?,?,?,?,?,?,?)";
        con = cn.getConnection();
        try {
        
            ps = con.prepareStatement(sql);
             ps.setString(1,us.getDescripcion());
            ps.setInt(2, us.getIdCliente());
            ps.setString(3,us.getFecha() );    
            ps.setString(4, us.getFechaDevolucion());    
            ps.setString(5, us.getTotalGeneral());  
            ps.setInt(6, us.getIdUsuario());
            ps.setInt(7, us.getEstado());
            ps.execute();
            return true;
        } catch (SQLException ex) {
            System.out.println(ex.toString());
            return false;
        }
    }
        public ResultSet obtenerUltimoIdPedido() throws Exception{
        ResultSet rs = null;
        try{       
            rs = ps.executeQuery("SELECT max(IdPedido) as IdPedido FROM pedido");
            return rs;
        }catch(SQLException SQLex){
            throw SQLex;            
        }        
    }

       public int GuardarDetallePedido(String Idpedido, String IdProducto, String Cantidad,  String Precio, String Total) {
        int resultado = 0;
        Connection conexion = null;

        String sql = "INSERT INTO pedidodetalle (IdPedido, IdProducto, Cantidad,Precio, total) VALUES (?,?,?,?,?)";
        con = cn.getConnection();
        try {
         
            ps = con.prepareStatement(sql);
            ps.setString(1, Idpedido);
            ps.setString(2, IdProducto);
            ps.setString(3, Cantidad);         
            ps.setString(4, Precio);
            ps.setString(5, Total);
            resultado = ps.executeUpdate();
            if (resultado > 0) {
               
            }
            conexion.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return resultado;
    }
       
        public void actualizarEstadoPedido(String Id,String estado){
        try{
               con = cn.getConnection();
            CallableStatement statement=con.prepareCall("{call SP_ActualizarEstadoPedido(?,?)}");
            statement.setString("pIdPedido",Id);
            statement.setString("pIdEstado",estado);        
            statement.executeUpdate();
            
        }catch(SQLException ex){
            ex.printStackTrace();
        }
        
    }
       
       
}
