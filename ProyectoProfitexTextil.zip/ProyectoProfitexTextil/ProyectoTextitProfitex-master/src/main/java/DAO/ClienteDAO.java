
package DAO;

import Configuracion.Conexion;
import Modelo.Cliente;
import Modelo.Usuario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ClienteDAO {
    
      Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    public boolean registrar(Cliente us) {
        String sql = "INSERT INTO cliente (Ruc, RazonSocial,Direccion,Telefono,RepresentanteLegal,IdUsuarioRegistro,estado) VALUES (?,?,?,?,?,?,?)";
        con = cn.getConnection();
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, us.getRuc());
            ps.setString(2, us.getRazonSocial());    
            ps.setString(3, us.getDireccion());
            ps.setString(4, us.getTelefono());
            ps.setString(5, us.getRepresentanteLegal());
            ps.setInt(6, us.getIdUsuario());
            ps.setInt(7, us.getEstado());
            ps.execute();
            return true;
        } catch (SQLException ex) {
            System.out.println(ex.toString());
            return false;
        }
    }

    public boolean actualizar(Cliente reg) {
        boolean res;
        String sql = "UPDATE cliente SET Ruc=?,RazonSocial=?, Direccion=?,Telefono=?,RepresentanteLegal=?,estado=? WHERE idcliente = ?";
        con = cn.getConnection();
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, reg.getRuc());
            ps.setString(2, reg.getRazonSocial());
            ps.setString(3, reg.getDireccion());
            ps.setString(4, reg.getTelefono());
            ps.setString(5, reg.getRepresentanteLegal());
            ps.setInt(6, reg.getEstado());
            ps.setInt(7, reg.getIdCliente());
            ps.execute();
            res = true;
        } catch (SQLException ex) {
            System.out.println(ex.toString());
            res = false;
        }
        return res;
    }
      public List Listar(String valor) {
        List<Cliente> lista = new ArrayList();
        try {
            con = cn.getConnection();
            if ("".equalsIgnoreCase(valor)) {
                String sql = "SELECT * FROM cliente ORDER BY IdCliente DESC";
                ps = con.prepareStatement(sql);
            } else {
                String sql = "SELECT * FROM cliente WHERE ruc LIKE '%" + valor + "%' OR razonsocial LIKE '%" + valor + "%'";
                ps = con.prepareStatement(sql);
            }
            rs = ps.executeQuery();
            while (rs.next()) {
                Cliente user = new Cliente();
                user.setIdCliente(rs.getInt("idcliente"));
                user.setRuc(rs.getString("ruc"));
                user.setRazonSocial(rs.getString("RazonSocial"));  
                user.setDireccion(rs.getString("direccion")); 
                 user.setTelefono(rs.getString("Telefono")); 
                  user.setRepresentanteLegal(rs.getString("RepresentanteLegal")); 
                user.setEstado(rs.getInt("estado"));  
                lista.add(user);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return lista;
    }
      
       public List ListarAyuda(String valor) {
        List<Cliente> lista = new ArrayList();
        try {
            con = cn.getConnection();
            if ("".equalsIgnoreCase(valor)) {
                String sql = "SELECT * FROM cliente where estado<>0 ORDER BY IdCliente DESC";
                ps = con.prepareStatement(sql);
            } else {
                String sql = "SELECT * FROM cliente WHERE ruc LIKE '%" + valor + "%' OR razonsocial LIKE '%" + valor + "%' and  estado<>0";
                ps = con.prepareStatement(sql);
            }
            rs = ps.executeQuery();
            while (rs.next()) {
                Cliente user = new Cliente();
                user.setIdCliente(rs.getInt("idcliente"));
                user.setRuc(rs.getString("ruc"));
                user.setRazonSocial(rs.getString("RazonSocial"));  
                user.setDireccion(rs.getString("direccion")); 
                 user.setTelefono(rs.getString("Telefono")); 
                  user.setRepresentanteLegal(rs.getString("RepresentanteLegal")); 
                user.setEstado(rs.getInt("estado"));  
                lista.add(user);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return lista;
    }
         public int ExisteCliente( String Id) {
        int resultado = 0;
        Connection conexion = null;

        String sql = "select count(*) as valor from cliente  where ruc='" + Id  +"'";
        con = cn.getConnection();
        try {
         
            ps = con.prepareStatement(sql);   
          
            rs = ps.executeQuery();
           if (rs.next()) {
                if (rs.getRow() > 0) {
                   resultado =rs.getInt("valor");
                 
                }
            }
            conexion.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return resultado;
    }
}
