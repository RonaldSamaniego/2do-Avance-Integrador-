
package DAO;

import Configuracion.Conexion;
import Modelo.Producto;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class ProductoDAO {
          Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;
        public boolean registrar(Producto us) {
        String sql = "INSERT INTO  producto(IdModelo,Descripcion,CostoPrenda,PrecioFabricacion,PrecioElaboracionDestajero,Stock,IdUsuarioRegistro,estado) VALUES (?,?,?,?,?,?,?,?)";
        con = cn.getConnection();
        try {
            ps = con.prepareStatement(sql);
                ps.setInt(1, us.getIdModelo());
            ps.setString(2, us.getDescripcion());
            ps.setString(3, us.getPrecio());
             ps.setDouble(4, us.getPrecioFabricacion());  
              ps.setDouble(5, us.getPrecioElaboracionDestajero());  
            ps.setString(6, us.getStock());        
            ps.setInt(7, us.getIdUsuario());
            ps.setInt(8, us.getEstado());
            ps.execute();
            return true;
        } catch (SQLException ex) {
            System.out.println(ex.toString());
            return false;
        }
    }

    public boolean actualizar(Producto reg) {
        boolean res;
        String sql = "UPDATE producto SET IdModelo=?,Descripcion=?,CostoPrenda=?,PrecioFabricacion=?,PrecioElaboracionDestajero=?, Stock=?,estado=? WHERE idproducto = ?";
        con = cn.getConnection();
        try {
            ps = con.prepareStatement(sql);
              ps.setInt(1, reg.getIdModelo());
            ps.setString(2, reg.getDescripcion());
            ps.setString(3, reg.getPrecio());
            ps.setDouble(4, reg.getPrecioFabricacion());
            ps.setDouble(5, reg.getPrecioElaboracionDestajero());
            ps.setString(6, reg.getStock());     
            ps.setInt(7, reg.getEstado());    
              ps.setInt(8, reg.getIdProducto());
            ps.execute();
            res = true;
        } catch (SQLException ex) {
            System.out.println(ex.toString());
            res = false;
        }
        return res;
    }
      public List Listar(String valor) {
        List<Producto> lista = new ArrayList();
        try {
            con = cn.getConnection();
            if ("".equalsIgnoreCase(valor)) {
                String sql = "SELECT p.IdProducto,m.idmodelo,m.nombre,p.Descripcion,p.costoprenda,p.PrecioFabricacion,p.PrecioElaboracionDestajero,p.stock,p.estado FROM Producto p inner join modelo m on p.idmodelo=m.idmodelo  ORDER BY p.IdProducto DESC";
                ps = con.prepareStatement(sql);
            } else {
                String sql = "SELECT p.IdProducto,m.idmodelo,m.nombre,p.Descripcion,p.costoprenda,p.PrecioFabricacion,p.PrecioElaboracionDestajero,p.stock,p.estado FROM Producto p inner join modelo m on p.idmodelo=m.idmodelo WHERE m.nombre LIKE '%" + valor + "%'";
                ps = con.prepareStatement(sql);
            }
            rs = ps.executeQuery();
            while (rs.next()) {
                Producto user = new Producto();
                user.setIdProducto(rs.getInt("IdProducto"));
                user.setIdModelo(rs.getInt("IdModelo"));
                user.setModelo(rs.getString("nombre"));
                user.setDescripcion(rs.getString("Descripcion"));
                user.setPrecio(rs.getString("CostoPrenda"));  
                 user.setPrecioFabricacion(rs.getDouble("PrecioFabricacion"));  
                  user.setPrecioElaboracionDestajero(rs.getDouble("PrecioElaboracionDestajero"));  
                user.setStock(rs.getString("stock"));      
                user.setEstado(rs.getInt("estado"));  
                lista.add(user);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return lista;
    }
       public List ListarAyuda(String valor) {
        List<Producto> lista = new ArrayList();
        try {
            con = cn.getConnection();
            if ("".equalsIgnoreCase(valor)) {
                String sql = "SELECT p.IdProducto,m.nombre,p.Descripcion,p.costoprenda,p.stock,p.estado FROM Producto p inner join modelo m on p.idmodelo=m.idmodelo where p.estado<>0   ORDER BY p.IdProducto DESC";
                ps = con.prepareStatement(sql);
            } else {
                String sql = "SELECT p.IdProducto,m.nombre,p.Descripcion,p.costoprenda,p.stock,p.estado FROM Producto  p inner join modelo m on p.idmodelo=m.idmodelo  WHERE m.nombre LIKE '%" + valor + "%' and p.estado<>0 ";
                ps = con.prepareStatement(sql);
            }
            rs = ps.executeQuery();
            while (rs.next()) {
                Producto user = new Producto();
                user.setIdProducto(rs.getInt("IdProducto"));
                user.setModelo(rs.getString("nombre"));
                user.setDescripcion(rs.getString("Descripcion"));
                user.setPrecio(rs.getString("CostoPrenda"));  
                user.setStock(rs.getString("stock"));      
                user.setEstado(rs.getInt("estado"));  
                lista.add(user);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return lista;
    }
      public void actualizarProductoStock(String Id,String cantidad){
        try{
               con = cn.getConnection();
            CallableStatement statement=con.prepareCall("{call sp_aumentar_stock (?,?)}");
            statement.setString("pidproducto",Id);
            statement.setString("pcantidad",cantidad);        
            statement.executeUpdate();
            
        }catch(SQLException ex){
            ex.printStackTrace();
        }
        
    }
      
      public int ExisteProductoModelo( String Id) {
        int resultado = 0;
        Connection conexion = null;

        String sql = "select * from producto  where idmodelo='" + Id  +"'";
        con = cn.getConnection();
        try {
         
            ps = con.prepareStatement(sql);          
            resultado = ps.executeUpdate();
            if (resultado > 0) {
               
            }
            conexion.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return resultado;
    }
       public void actualizarEstadoModeloProducto(String Id){
        try{
               con = cn.getConnection();
            CallableStatement statement=con.prepareCall("{call sp_actualizar_estado_modelo_producto (?)}");
            statement.setString("pidmodelo",Id);                
            statement.executeUpdate();
            
        }catch(SQLException ex){
            ex.printStackTrace();
        }
       }
}
