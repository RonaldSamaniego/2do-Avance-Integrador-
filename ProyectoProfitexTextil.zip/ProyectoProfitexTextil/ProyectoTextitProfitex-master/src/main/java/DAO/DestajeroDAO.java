
package DAO;

import Configuracion.Conexion;
import Modelo.Cliente;
import Modelo.Destajero;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


public class DestajeroDAO {
      Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    public boolean registrar(Destajero us) {
        String sql = "INSERT INTO empresaDestajero (Ruc, RazonSocial,Direccion,Telefono,RepresentanteLegal,IdUsuarioRegistro,estado) VALUES (?,?,?,?,?,?,?)";
        con = cn.getConnection();
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, us.getRuc());
            ps.setString(2, us.getRazonSocial());    
            ps.setString(3, us.getDireccion());
            ps.setString(4, us.getTelefono());
            ps.setString(5, us.getRepresentanteLegal());
            ps.setInt(6, us.getIdUsuario());
            ps.setInt(7, us.getEstado());
            ps.execute();
            return true;
        } catch (SQLException ex) {
            System.out.println(ex.toString());
            return false;
        }
    }

    public boolean actualizar(Destajero reg) {
        boolean res;
        String sql = "UPDATE EmpresaDestajero SET Ruc=?,RazonSocial=?, Direccion=?,Telefono=?,RepresentanteLegal=? WHERE idEmpresaDestajero = ?";
        con = cn.getConnection();
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, reg.getRuc());
            ps.setString(2, reg.getRazonSocial());
            ps.setString(3, reg.getDireccion());
            ps.setString(4, reg.getTelefono());
            ps.setString(5, reg.getRepresentanteLegal()); 
            ps.setInt(6, reg.getIdDestajero());
            ps.execute();
            res = true;
        } catch (SQLException ex) {
            System.out.println(ex.toString());
            res = false;
        }
        return res;
    } 
    
      public List Listar(String valor) {
        List<Destajero> lista = new ArrayList();
        try {
            con = cn.getConnection();
            if ("".equalsIgnoreCase(valor)) {
                String sql = "SELECT * FROM EmpresaDestajero ORDER BY IdEmpresaDestajero DESC";
                ps = con.prepareStatement(sql);
            } else {
                String sql = "SELECT * FROM EmpresaDestajero WHERE ruc LIKE '%" + valor + "%' OR razonsocial LIKE '%" + valor + "%'";
                ps = con.prepareStatement(sql);
            }
            rs = ps.executeQuery();
            while (rs.next()) {
                Destajero user = new Destajero();
                user.setIdDestajero(rs.getInt("IdEmpresaDestajero"));
                user.setRuc(rs.getString("ruc"));
                user.setRazonSocial(rs.getString("RazonSocial"));  
                user.setDireccion(rs.getString("direccion")); 
                 user.setTelefono(rs.getString("Telefono")); 
                  user.setRepresentanteLegal(rs.getString("RepresentanteLegal")); 
                user.setEstado(rs.getInt("estado"));  
                lista.add(user);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return lista;
    }
          public List ListarAyudaDestajero(String valor) {
        List<Destajero> lista = new ArrayList();
        try {
            con = cn.getConnection();
            if ("".equalsIgnoreCase(valor)) {
                String sql = "SELECT IdEmpresaDestajero,RUC,RazonSocial,estado, CASE WHEN Estado=1 THEN 'Libre' ELSE 'Ocupado' END AS EstadoNombre FROM `empresadestajero` where estado<>0 ORDER BY IdEmpresaDestajero DESC";
                ps = con.prepareStatement(sql);
            } else {
                String sql = "SELECT IdEmpresaDestajero,RUC,RazonSocial,estado, CASE WHEN Estado=1 THEN 'Libre' ELSE 'Ocupado' END  AS EstadoNombre FROM `empresadestajero`  where estado<>0 and  ruc LIKE '%" + valor + "%' OR razonsocial LIKE '%" + valor + "%'";
                ps = con.prepareStatement(sql);
            }
            rs = ps.executeQuery();
            while (rs.next()) {
                Destajero user = new Destajero();
                user.setIdDestajero(rs.getInt("IdEmpresaDestajero"));
                user.setRuc(rs.getString("ruc"));
                user.setRazonSocial(rs.getString("RazonSocial"));                
                user.setEstadoNombre(rs.getString("EstadoNombre"));  
                lista.add(user);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return lista;
    }
          
    public void actualizarEstadoDestajero(String Id,String estado){
        try{
               con = cn.getConnection();
            CallableStatement statement=con.prepareCall("{call SP_ActualizarEstadoEmpresaDestajero(?,?)}");
            statement.setString("piddestajero",Id);
            statement.setString("pIdEstado",estado);        
            statement.executeUpdate();
            
        }catch(SQLException ex){
            ex.printStackTrace();
        }
        
    }
     public int ExisteDestajero( String Id) {
        int resultado = 0;
        Connection conexion = null;

        String sql = "select count(*) as valor from empresadestajero  where ruc='" + Id  +"'";
        con = cn.getConnection();
        try {
         
            ps = con.prepareStatement(sql);   
          
            rs = ps.executeQuery();
           if (rs.next()) {
                if (rs.getRow() > 0) {
                   resultado =rs.getInt("valor");
                 
                }
            }
            conexion.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return resultado;
    }
      
}
