
package DAO;

import Configuracion.Conexion;
import Modelo.Pedido;
import Modelo.ServicioDestajero;
import Modelo.ServicioDestajeroDetalle;
import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;


public class ServicioDestajeroDAO {
     Connection con;
    Conexion cn = new Conexion();
    PreparedStatement ps;
    ResultSet rs;
    
     public List Listar(String valor) {
        List<ServicioDestajero> lista = new ArrayList();
        try {
            con = cn.getConnection();
            if ("".equalsIgnoreCase(valor)) {
                String sql = "SELECT   s.IdServicioDestajero,p.IdPedido,cl.razonsocial,e.IdEmpresaDestajero,e.RazonSocial as EmpresaDestajero,s.Fecha,s.FechaDevolucion,s.CantidadTotalEntregado,s.CantidadTotalCulminado,s.TotalPagar,s.Estado FROM serviciodestajero s inner join pedido p on s.IdPedido=p.IdPedido inner join empresadestajero e on s.IdEmpresDestajero=e.IdEmpresaDestajero inner join cliente cl on p.idcliente=cl.idcliente  ORDER BY s.IdServicioDestajero DESC";
                ps = con.prepareStatement(sql);
            } else {
                String sql = "SELECT   s.IdServicioDestajero,p.IdPedido,cl.razonsocial,e.IdEmpresaDestajero,e.RazonSocial as EmpresaDestajero,s.Fecha,s.FechaDevolucion,s.CantidadTotalEntregado,s.CantidadTotalCulminado,s.TotalPagar,s.Estado FROM serviciodestajero s inner join pedido p on s.IdPedido=p.IdPedido inner join empresadestajero e on s.IdEmpresDestajero=e.IdEmpresaDestajero inner join cliente cl on p.idcliente=cl.idcliente WHERE p.Descripcion like '%"+valor+"%' or   e.razonsocial LIKE '%" + valor + "%'";
                ps = con.prepareStatement(sql);
            }
            rs = ps.executeQuery();
            while (rs.next()) {
                ServicioDestajero user = new ServicioDestajero();
                user.setIdServicioDestajero(rs.getInt("IdServicioDestajero"));
                user.setIdPedido(rs.getInt("IdPedido"));  
                user.setIPedido(rs.getString("razonsocial"));  
                user.setIdDestajero(rs.getInt("IdEmpresaDestajero"));
                user.setDestajero(rs.getString("EmpresaDestajero"));
                user.setFecha(rs.getString("fecha"));  
                user.setFechaDevolucion(rs.getString("fechaDevolucion")); 
                user.setCantidadTotalEntregado(rs.getString("CantidadTotalEntregado")); 
                user.setCantidadTotalCulminado(rs.getString("CantidadTotalCulminado")); 
                user.setTotalPagar(rs.getString("TotalPagar")); 
                user.setEstado(rs.getInt("estado"));  
                lista.add(user);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return lista;
    }
      public List ListarPedidoProducto(String valor) {
        List<ServicioDestajeroDetalle > lista = new ArrayList();
        try {
            con = cn.getConnection();
           
             String sql = "SELECT p.IdServicioDestajero,m.Nombre as ProductoNombre,p.Cantidad,p.precio,p.Total FROM serviciodestajerodetalle p inner JOIN producto pr on p.IdProducto=pr.IdProducto inner join modelo m on pr.idmodelo=m.idmodelo WHERE  p.IdServicioDestajero = '" + valor + "'";
                ps = con.prepareStatement(sql);
           
            rs = ps.executeQuery();
            while (rs.next()) {
                ServicioDestajeroDetalle  user = new ServicioDestajeroDetalle ();
                user.setIdServicio(rs.getInt("IdServicioDestajero"));
                user.setProducto(rs.getString("ProductoNombre"));
                user.setCantidad(rs.getString("Cantidad"));
                user.setPrecio(rs.getString("Precio"));
                user.setTotal(rs.getString("Total")); 
                
                lista.add(user);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return lista;
    }
        public List ListarServicioProducto(String valor) {
        List<ServicioDestajeroDetalle > lista = new ArrayList();
        try {
            con = cn.getConnection();
           
             String sql = "SELECT s.IdServicioDestajero,p.IdProducto,m.Nombre as ProductoNombre,p.CostoPrenda,s.Cantidad,s.CantidadEntregada,s.precio,s.SubTotal,s.Descuento,s.Total,s.Totalpagar FROM serviciodestajerodetalle s INNER JOIN producto p on s.IdProducto=p.IdProducto inner join modelo m on p.idmodelo=m.idmodelo WHERE  s.IdServicioDestajero = '" + valor + "'";
                ps = con.prepareStatement(sql);
           
            rs = ps.executeQuery();
            while (rs.next()) {
                ServicioDestajeroDetalle  user = new ServicioDestajeroDetalle ();
                user.setIdServicio(rs.getInt("IdServicioDestajero"));
                user.setIdProducto(rs.getInt("IdProducto"));
                user.setProducto(rs.getString("ProductoNombre"));
                user.setCostoPrenda(rs.getString("CostoPrenda"));
                user.setCantidad(rs.getString("Cantidad"));
                user.setCantidadEntregada(rs.getString("CantidadEntregada"));
                user.setPrecio(rs.getString("Precio"));
                user.setSubtotal(rs.getString("SubTotal"));
                user.setDescuento(rs.getString("Descuento"));
                user.setTotal(rs.getString("Total")); 
                  user.setTotalPagar(rs.getString("TotalPagar")); 
                lista.add(user);
            }
        } catch (SQLException e) {
            System.out.println(e.toString());
        }
        return lista;
    }
     public boolean registrarServicioDestajero(ServicioDestajero us) {
        String sql = "INSERT INTO serviciodestajero (IdPedido,IdEmpresDestajero	,Fecha,FechaDevolucion,TotalGeneral,IdUsuarioRegistro,CantidadTotalEntregado,estado) VALUES (?,?,?,?,?,?,?,?)";
        con = cn.getConnection();
        try {
        
            ps = con.prepareStatement(sql);
             ps.setInt(1,us.getIdPedido());
            ps.setInt(2, us.getIdDestajero());
            ps.setString(3,us.getFecha() );    
            ps.setString(4, us.getFechaDevolucion());    
            ps.setString(5, us.getTotalGeneral());            
            ps.setInt(6, us.getIdUsuario());
            ps.setString(7, us.getCantidadTotalEntregado());         
            ps.setInt(8, us.getEstado());
            ps.execute();
            return true;
        } catch (SQLException ex) {
            System.out.println(ex.toString());
            return false;
        }
    }
        public ResultSet obtenerUltimoIdServicioDestajero() throws Exception{
        ResultSet rs = null;
        try{       
            rs = ps.executeQuery("SELECT max(IdServicioDestajero) as IdServicioDestajero FROM serviciodestajero");
            return rs;
        }catch(SQLException SQLex){
            throw SQLex;            
        }        
    }

       public int GuardarDetalleServicio(String IdServicioDestajero, String IdProducto, String Cantidad,  String Precio, String Total) {
        int resultado = 0;
        Connection conexion = null;

        String sql = "INSERT INTO serviciodestajerodetalle(IdServicioDestajero, IdProducto, Cantidad,Precio, total) VALUES (?,?,?,?,?)";
        con = cn.getConnection();
        try {
         
            ps = con.prepareStatement(sql);
            ps.setString(1, IdServicioDestajero);
            ps.setString(2, IdProducto);
            ps.setString(3, Cantidad);         
            ps.setString(4, Precio);
            ps.setString(5, Total);
            resultado = ps.executeUpdate();
            if (resultado > 0) {
               
            }
            conexion.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        return resultado;
    }
       
         public boolean actualizarServicioDetalle(ServicioDestajeroDetalle reg) {
        boolean res;
        String sql = "UPDATE serviciodestajerodetalle SET CantidadEntregada=?,SubTotal=?,Descuento=?,TotalPagar=? WHERE IdServicioDestajero=? and 	 idproducto = ?";
        con = cn.getConnection();
        try {
            ps = con.prepareStatement(sql);
            ps.setString(1, reg.getCantidadEntregada());
            ps.setString(2, reg.getSubtotal());
            ps.setString(3, reg.getDescuento());
            ps.setString(4, reg.getTotalPagar());             
            ps.setInt(5, reg.getIdServicio());    
              ps.setInt(6, reg.getIdProducto());
            ps.execute();
            res = true;
        } catch (SQLException ex) {
            System.out.println(ex.toString());
            res = false;
        }
        return res;
    }
         
          public boolean actualizarServicioCal(ServicioDestajero reg) {
        boolean res;
        String sql = "UPDATE serviciodestajero SET CantidadTotalCulminado=?,Descuento=?,TotalPagar=? WHERE IdServicioDestajero=? ";
        con = cn.getConnection();
        try {
            ps = con.prepareStatement(sql);
            ps.setDouble(1, Double.parseDouble(reg.getCantidadTotalCulminado()));
            ps.setDouble(2, Double.parseDouble(reg.getDescuento()));
            ps.setDouble(3,Double.parseDouble( reg.getTotalPagar()));   
         
            ps.setInt(4, reg.getIdServicioDestajero());
           
            ps.execute();
            res = true;
        } catch (SQLException ex) {
            System.out.println(ex.toString());
            res = false;
        }
        return res;
    }
          
           public void actualizarEstadoServicio(String Id,String estado){
        try{
               con = cn.getConnection();
            CallableStatement statement=con.prepareCall("{call SP_ActualizarEstadoServicioDestajero(?,?)}");
            statement.setString("ipservicio",Id);
            statement.setString("pIdEstado",estado);        
            statement.executeUpdate();
            
        }catch(SQLException ex){
            ex.printStackTrace();
        }
        
    }
      
}
