/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JPanel.java to edit this template
 */
package Vistas;

import DAO.DestajeroDAO;
import DAO.PedidoDAO;
import DAO.ServicioDestajeroDAO;
import Modelo.Pedido;
import Modelo.PedidoDetalle;
import Modelo.ServicioDestajero;
import Modelo.ServicioDestajeroDetalle;
import Utilitarios.ColorearTablaPedido;
import Utilitarios.Utilitario;
import static Vistas.FrmBuscarPedido.modelodetalleproducto;
import static Vistas.FrmPricipalPedido.rs;
//import static Vistas.FrmPricipalPedido.txtcliente;
//import static Vistas.FrmPricipalPedido.txtidcliente;
import java.awt.Color;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

/**
 *
 * @author XECURE01
 */
public class FrmPrincipalServicioDestajero extends javax.swing.JPanel {
  PedidoDAO pedidoDao = new PedidoDAO();
    Pedido ped = new Pedido();  
    ServicioDestajeroDAO servicioDao= new ServicioDestajeroDAO();
    ServicioDestajero serv = new ServicioDestajero();  
    DestajeroDAO destajeroDao= new DestajeroDAO();
    DefaultTableModel modelo = new DefaultTableModel();
       DefaultTableModel modelodet = new DefaultTableModel();
        Utilitario uti = new Utilitario();
           int idservicio;
           
           //--------
           static String idpedidoedit;
           static String idservedit;
           static String idservedesdit;
            static String servedesdit;
           static String  cantidentreedit;
           static String estado;
    /**
     * Creates new form FrmPrincipalServicioDestajero
     */
    public FrmPrincipalServicioDestajero() {
        initComponents();
        LimpiarTable();
        ListarServicio();
    }
    public void LimpiarTable() 
        {
        for (int i = 0; i < modelo.getRowCount(); i++) {
            modelo.removeRow(i);
            i = i - 1;
        }
    }
    
    public void limpiardetalle()
    { for (int i = 0; i <    modelodetalleproducto.getRowCount(); i++) {
               modelodetalleproducto.removeRow(i);
            i = i - 1;
        }
   
     
    }
    public void ListarServicio() {
        List<ServicioDestajero> Listar = servicioDao.Listar(txtbuscarpedido.getText());
        modelo = (DefaultTableModel) tblservicio.getModel();
        Object[] ob = new Object[11];
        for (int i = 0; i < Listar.size(); i++) {
            ob[0] = Listar.get(i).getIdServicioDestajero();
            ob[1] = Listar.get(i).getIdPedido();
            ob[2] = Listar.get(i).getPedido();
            ob[3] = Listar.get(i).getIdDestajero();
            ob[4] = Listar.get(i).getDestajero();
            ob[5] = Listar.get(i).getFecha();
            ob[6] = Listar.get(i).getFechaDevolucion();
            ob[7] = Listar.get(i).getCantidadTotalEntregado();
            ob[8] = Listar.get(i).getCantidadTotalCulminado();
            ob[9] = Listar.get(i).getTotalPagar();
            if(Listar.get(i).getEstado()==1) {
                 ob[10] ="Pendiente";
            }
            else if(Listar.get(i).getEstado()==2) {
                 ob[10] ="Completado";
            }
              else if(Listar.get(i).getEstado()==3) {
                 ob[10] ="Entregado";
            }
               else if(Listar.get(i).getEstado()==4) {
                 ob[10] ="Incompleto";
            }
            
            modelo.addRow(ob);
        }
        tblservicio.setModel(modelo);  
        tblservicio.getColumnModel().getColumn(1).setMaxWidth(0);
        tblservicio.getColumnModel().getColumn(1).setMinWidth(0);
        tblservicio.getTableHeader().getColumnModel().getColumn(1).setMaxWidth(0);
        tblservicio.getTableHeader().getColumnModel().getColumn(1).setMinWidth(0);
    //-----------------
       tblservicio.getColumnModel().getColumn(3).setMaxWidth(0);
        tblservicio.getColumnModel().getColumn(3).setMinWidth(0);
        tblservicio.getTableHeader().getColumnModel().getColumn(3).setMaxWidth(0);
        tblservicio.getTableHeader().getColumnModel().getColumn(3).setMinWidth(0);
        color(tblservicio);
    }
    private void ListarServicioDetalle(String id) {
        List<ServicioDestajeroDetalle> Listar = servicioDao.ListarPedidoProducto(id);
        modelodet = (DefaultTableModel) TblServicioDetalle.getModel();
        Object[] ob = new Object[5];
        for (int i = 0; i < Listar.size(); i++) {
            ob[0] = Listar.get(i).getIdServicio();
            ob[1] = Listar.get(i).getProducto();
            ob[2] = Listar.get(i).getCantidad();
            ob[3] = Listar.get(i).getPrecio();
            ob[4] = Listar.get(i).getTotal();
            
            
            modelodet.addRow(ob);
        }
        TblServicioDetalle.setModel(modelodet);
        color(TblServicioDetalle);
    }
 private void ObtenerPedidoProductos(String id) {
        List<PedidoDetalle> Listar = pedidoDao.ObtenerPedidoProducto(id);
        modelo = (DefaultTableModel) tblDetalleProducto.getModel();
        Object[] ob = new Object[5];
        for (int i = 0; i < Listar.size(); i++) {
            ob[0] = Listar.get(i).getIdProducto();
            ob[1] = Listar.get(i).getProducto();
            ob[2] = Listar.get(i).getCantidad();         
            ob[3] = Listar.get(i).getPrecio();           
            ob[4] = Listar.get(i).getTotal(); 
            modelo.addRow(ob);
        }
        
        
        tblDetalleProducto.setModel(modelo);
              
        color(tblDetalleProducto);
    }
      
    private void color(JTable tabla) {
        JTableHeader header = tabla.getTableHeader();
        header.setOpaque(false);
        header.setBackground(new Color(0, 110, 255));
        header.setForeground(Color.white);
    }
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        txtserviciodestajero = new javax.swing.JTextField();
        btngrabar = new javax.swing.JButton();
        jButton30 = new javax.swing.JButton();
        btnbuscardestajero = new javax.swing.JButton();
        jPanel12 = new javax.swing.JPanel();
        jScrollPane6 = new javax.swing.JScrollPane();
        tblDetalleProducto = new javax.swing.JTable();
        jLabel22 = new javax.swing.JLabel();
        lbltotal = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        txtcantidadtotal = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        txtidserviciodestajero = new javax.swing.JTextField();
        jLabel9 = new javax.swing.JLabel();
        lblidserviciodestajero = new javax.swing.JLabel();
        btnbuscarpedido = new javax.swing.JButton();
        txtpedido = new javax.swing.JTextField();
        lblidpedido = new javax.swing.JTextField();
        jLabel23 = new javax.swing.JLabel();
        mskfecha = new com.toedter.calendar.JDateChooser();
        mskfechdevolucion = new com.toedter.calendar.JDateChooser();
        jLabel37 = new javax.swing.JLabel();
        txtbuscarpedido = new javax.swing.JTextField();
        jButton31 = new javax.swing.JButton();
        jScrollPane7 = new javax.swing.JScrollPane();
        tblservicio = new javax.swing.JTable();
        jScrollPane5 = new javax.swing.JScrollPane();
        TblServicioDetalle = new javax.swing.JTable();
        btnculminado = new javax.swing.JButton();
        btnactualizar = new javax.swing.JButton();

        jLabel1.setFont(new java.awt.Font("Segoe UI", 1, 24)); // NOI18N
        jLabel1.setText("LISTA DE SERVICIO DESTAJEROS");

        jPanel11.setBorder(javax.swing.BorderFactory.createTitledBorder("Registro Pedido"));

        jLabel17.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel17.setText("Pedido");

        jLabel18.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel18.setText("Fecha");

        txtserviciodestajero.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        txtserviciodestajero.setEnabled(false);

        btngrabar.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btngrabar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/save.png"))); // NOI18N
        btngrabar.setText("Grabar");
        btngrabar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btngrabarActionPerformed(evt);
            }
        });

        jButton30.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton30.setIcon(new javax.swing.ImageIcon(getClass().getResource("/eliminar.png"))); // NOI18N
        jButton30.setText("Eliminar");

        btnbuscardestajero.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/buscar.png"))); // NOI18N
        btnbuscardestajero.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbuscardestajeroActionPerformed(evt);
            }
        });

        jPanel12.setBorder(javax.swing.BorderFactory.createTitledBorder("Registro Producto Pedido"));

        tblDetalleProducto.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "ProductoNombre", "Cantidad", "Precio", "Total"
            }
        ));
        jScrollPane6.setViewportView(tblDetalleProducto);

        jLabel22.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel22.setText("TOTAL:");

        lbltotal.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        lbltotal.setForeground(new java.awt.Color(0, 102, 153));
        lbltotal.setText("###");

        jLabel24.setFont(new java.awt.Font("Times New Roman", 3, 18)); // NOI18N
        jLabel24.setText("CANTIDAD TOTAL:");

        txtcantidadtotal.setFont(new java.awt.Font("Times New Roman", 1, 24)); // NOI18N
        txtcantidadtotal.setForeground(new java.awt.Color(0, 102, 153));
        txtcantidadtotal.setText("###");

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane6)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                        .addGap(0, 201, Short.MAX_VALUE)
                        .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 166, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txtcantidadtotal, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(lbltotal, javax.swing.GroupLayout.PREFERRED_SIZE, 120, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap())
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                .addComponent(jScrollPane6, javax.swing.GroupLayout.PREFERRED_SIZE, 149, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(lbltotal)
                    .addComponent(jLabel24, javax.swing.GroupLayout.PREFERRED_SIZE, 33, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txtcantidadtotal))
                .addContainerGap(16, Short.MAX_VALUE))
        );

        jLabel21.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel21.setText("Fecha Devolucion");

        txtidserviciodestajero.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        txtidserviciodestajero.setEnabled(false);

        jLabel9.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel9.setText("IdServicioDestajero");

        lblidserviciodestajero.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N

        btnbuscarpedido.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/buscar.png"))); // NOI18N
        btnbuscarpedido.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnbuscarpedidoActionPerformed(evt);
            }
        });

        txtpedido.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        txtpedido.setEnabled(false);

        lblidpedido.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        lblidpedido.setEnabled(false);

        jLabel23.setFont(new java.awt.Font("Times New Roman", 3, 14)); // NOI18N
        jLabel23.setText("Servicio Destajero");

        mskfecha.setDateFormatString("dd/MM/yyyy");

        mskfechdevolucion.setDateFormatString("dd/MM/yyyy");

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 89, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addComponent(jLabel9)
                        .addGap(18, 18, 18)
                        .addComponent(lblidserviciodestajero, javax.swing.GroupLayout.PREFERRED_SIZE, 115, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(0, 475, Short.MAX_VALUE))
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(21, 21, 21)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addComponent(lblidpedido, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtpedido)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnbuscarpedido))
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addComponent(txtidserviciodestajero, javax.swing.GroupLayout.PREFERRED_SIZE, 80, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txtserviciodestajero)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btnbuscardestajero))
                    .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 125, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel11Layout.createSequentialGroup()
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel18)
                            .addComponent(mskfecha, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(26, 26, 26)
                        .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel11Layout.createSequentialGroup()
                                .addGap(6, 6, 6)
                                .addComponent(mskfechdevolucion, javax.swing.GroupLayout.PREFERRED_SIZE, 218, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(jLabel21))))
                .addContainerGap())
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel11Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(btngrabar)
                .addGap(18, 18, 18)
                .addComponent(jButton30)
                .addGap(180, 180, 180))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(13, 13, 13)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblidserviciodestajero, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel17)
                .addGap(1, 1, 1)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblidpedido, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtpedido, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnbuscarpedido))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jLabel23)
                .addGap(18, 18, 18)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txtidserviciodestajero, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(txtserviciodestajero, javax.swing.GroupLayout.PREFERRED_SIZE, 35, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(btnbuscardestajero))
                .addGap(12, 12, 12)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel18)
                    .addComponent(jLabel21))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(mskfechdevolucion, javax.swing.GroupLayout.DEFAULT_SIZE, 37, Short.MAX_VALUE)
                    .addComponent(mskfecha, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jButton30)
                    .addComponent(btngrabar)))
        );

        jLabel37.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/buscar.png"))); // NOI18N
        jLabel37.setText("Buscar");

        txtbuscarpedido.addKeyListener(new java.awt.event.KeyAdapter() {
            public void keyReleased(java.awt.event.KeyEvent evt) {
                txtbuscarpedidoKeyReleased(evt);
            }
        });

        jButton31.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jButton31.setIcon(new javax.swing.ImageIcon(getClass().getResource("/nuevo.png"))); // NOI18N
        jButton31.setText("Nuevo");
        jButton31.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton31ActionPerformed(evt);
            }
        });

        tblservicio.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "IdServicio", "IdPedido", "Pedido", "IdEmpresaDestajero", "EmpresaDestajero", "Fecha", "FechaDevolucion", "CantidadEntregado", "CantidadCulminado", "TotalPagar", "Estado"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tblservicio.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tblservicioMouseClicked(evt);
            }
        });
        jScrollPane7.setViewportView(tblservicio);

        TblServicioDetalle.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Id", "ProductoNombre", "Cantidad", "Precio", "Total"
            }
        ));
        jScrollPane5.setViewportView(TblServicioDetalle);

        btnculminado.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        btnculminado.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/editar.png"))); // NOI18N
        btnculminado.setText("Culminado");
        btnculminado.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnculminadoActionPerformed(evt);
            }
        });

        btnactualizar.setIcon(new javax.swing.ImageIcon(getClass().getResource("/imagenes/actualizar.png"))); // NOI18N
        btnactualizar.setText("Actualizar");
        btnactualizar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnactualizarActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(this);
        this.setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(17, 17, 17)
                        .addComponent(jLabel1))
                    .addGroup(layout.createSequentialGroup()
                        .addContainerGap()
                        .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(jLabel37, javax.swing.GroupLayout.PREFERRED_SIZE, 77, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(txtbuscarpedido, javax.swing.GroupLayout.PREFERRED_SIZE, 189, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jButton31)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(btnculminado)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                .addComponent(btnactualizar))
                            .addComponent(jScrollPane5)
                            .addComponent(jScrollPane7))))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jLabel37)
                                    .addComponent(txtbuscarpedido, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(jButton31)
                                    .addComponent(btnculminado)))
                            .addComponent(btnactualizar, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane7, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane5, javax.swing.GroupLayout.PREFERRED_SIZE, 240, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(36, 36, 36))))
        );
    }// </editor-fold>//GEN-END:initComponents
private boolean  Validar()
    { 
        if(txtpedido.getText().equals(""))
        {
          JOptionPane.showMessageDialog(null, "Ingrese el Pedido");
          btnbuscarpedido.requestFocus();
            return false;
        }
        if(txtserviciodestajero.getText().equals(""))
        {
          JOptionPane.showMessageDialog(null, "Ingrese el Destajero");
          btnbuscardestajero.requestFocus();
            return false;
        }
//          if ( uti.validarFecha(mskfecha.getText())==false) {
//          JOptionPane.showMessageDialog(null, "Ingrese la Fecha de Entrega Correcta");
//          mskfecha.requestFocus();
//            return false;
//          
//          }
//          if ( uti.validarFecha(mskfechdevolucion.getDate())==false) {
//          JOptionPane.showMessageDialog(null, "Ingrese la Fecha de Devolucion Correcta");
//          mskfecha.requestFocus();
//            return false;
//          
//          }
           if(mskfecha.getDate()==null)
          {
             JOptionPane.showMessageDialog(null, "Ingrese la Fecha Correcta");
            mskfecha.requestFocus();
            return false; 
          }
          if (mskfechdevolucion.getDate()==null)
          {
              JOptionPane.showMessageDialog(null, "Ingrese la Fecha de Devolucion Correcta"); 
             mskfechdevolucion.requestFocus();
           return false;
          }
//          if (uti.isValid(uti.RetornFormatofecha(mskfecha.getDate().toString()))==false)
//          {
//               JOptionPane.showMessageDialog(null, "Ingrese la Fecha Correcta");
//         mskfecha.requestFocus();
//         return false;
//          }
//          if (uti.isValid(uti.RetornFormatofecha(mskfechdevolucion.getDate().toString()))==false) {
//           JOptionPane.showMessageDialog(null, "Ingrese la Fecha de Devolucion Correcta"); 
//             mskfechdevolucion.requestFocus();
//           return false;
//         
//          }
          if(uti.validarEntreFechas(mskfecha.getDate(),mskfechdevolucion.getDate())==false)
          {
              JOptionPane.showMessageDialog(null, "La Fecha no pueede ser Mayor a la Fecha de Devolucion");
              mskfecha.requestFocus();
              return false;
          }
        if( tblDetalleProducto.getRowCount()<=0)
        {
          JOptionPane.showMessageDialog(null, "Debe Ingresar por lo menos 1 Producto");          
            return false;
        }
        return true;
    }
 private void LimpiarDatos(){
        lblidpedido.setText("");
        txtpedido.setText("");
        txtidserviciodestajero.setText("");
        txtserviciodestajero.setText("");               
         lbltotal.setText("");   
         mskfecha.setDate(null);
         mskfechdevolucion.setDate(null);
         txtcantidadtotal.setText("");
       //  limpiarTabla();
         }
//   void limpiarTabla() {
//        try {
//            int filas = tblDetalleProducto.getRowCount();
//            for (int i = 0; filas > i; i++) {
//                dt.removeRow(0);
//            }
//        } catch (Exception e) {
//            JOptionPane.showMessageDialog(null, "Error al limpiar la tabla.");
//        }
//    }
   private void registrarServicioDestajero(){
         if(Validar()==false) return;
         String id=lblidserviciodestajero.getText();
         serv.setIdPedido(Integer.parseInt(lblidpedido.getText()));
        serv.setIdDestajero(Integer.parseInt(txtidserviciodestajero.getText()));
       serv.setFecha(((JTextField)mskfecha.getDateEditor().getUiComponent()).getText());
        serv.setFechaDevolucion(((JTextField)mskfechdevolucion.getDateEditor().getUiComponent()).getText());   
        serv.setTotalGeneral(lbltotal.getText());
        serv.setCantidadTotalEntregado(txtcantidadtotal.getText());
        serv.setEstado(1);
        serv.setIdUsuario(  Integer.parseInt(FrmDashboard.lblidusuario.getText()));
        if(id.equals("")){
            if (servicioDao.registrarServicioDestajero(serv)) {
              guardarDetalle();
              pedidoDao.actualizarEstadoPedido(lblidpedido.getText(), "2");
              destajeroDao.actualizarEstadoDestajero(txtidserviciodestajero.getText(),"2");
                JOptionPane.showMessageDialog(null, "Servicio Destajero  Registrado");
                 LimpiarDatos();
                
            } else {
                JOptionPane.showMessageDialog(null, "Error al Registrar");
            }
        }
        else {
//            ped.setIdClienteInteger.getInteger( lblidcliente.getText()));
//            if (clienteDao.actualizar(clie)) {
//                JOptionPane.showMessageDialog(null, "Cliente Modificado");
//                limpiarCliente();
//            } else {
//                JOptionPane.showMessageDialog(null, "Error al Modificar");
//            }
        }
       }
     void obtenerUltimoIdServicioDestajero() {
        try {
            
            rs = servicioDao.obtenerUltimoIdServicioDestajero();
            while (rs.next()) {
                idservicio = rs.getInt(1);
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, ex.getMessage());
            System.out.println(ex.getMessage());
        }
    }
     void guardarDetalle(){
        obtenerUltimoIdServicioDestajero();
        
        
        String strId;
        int fila=0;
        double cant = 0,ncant,stock;   
        fila =tblDetalleProducto.getRowCount();
        for (int f=0; f<fila; f++){
            String IdServicioDestajero = String.valueOf(idservicio);
            String IdProducto = String.valueOf(tblDetalleProducto.getModel().getValueAt(f, 0));               
            String Cantidad = String.valueOf(tblDetalleProducto.getModel().getValueAt(f, 2));
            String precio = String.valueOf(tblDetalleProducto.getModel().getValueAt(f, 3));
            String Total = String.valueOf(tblDetalleProducto.getModel().getValueAt(f, 4));
            
//           if (num == 0) {
          if(  servicioDao.GuardarDetalleServicio(IdServicioDestajero, IdProducto,Cantidad, precio, Total)>0)
          {  //productoDao.actualizarProductoStock(IdProducto, Cantidad);  
          }
                  
//            try{
//                Metodos_Productos oProducto=new Metodos_Productos();
//                
//                rs= oProducto.listarProductoActivoPorParametro("id",((String) tblDetalleProducto.getValueAt(f, 0)));
//                while (rs.next()) {
//                            cant=Double.parseDouble(rs.getString(4));
//                }
//                
//
//            } catch (Exception ex) {
//                JOptionPane.showMessageDialog(this,ex.getMessage());
//                System.out.println(ex.getMessage());
//            }        
//
//            
//            Metodos_Productos oProducto=new Metodos_Productos();
//            
//        strId =  ((String) tblDetalleProducto.getValueAt(f, 0));
//
//        ncant=Double.parseDouble(String.valueOf(tblDetalleProducto.getModel().getValueAt(f, 5)));
//
//        stock=cant-ncant;
//        String Producto = String.valueOf(stock);
//        if (num == 0) {
//        oProducto.actualizarProductoStock(strId, Producto);
//        }
            
//        }
    }
}
    private void btngrabarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btngrabarActionPerformed
        // TODO add your handling code here:
    if(Validar()==false)return;
   int result = JOptionPane.showConfirmDialog(this, "¿Desea Generar el Servicio ?", "Mensaje del Sistema", JOptionPane.YES_NO_OPTION);
       if (result == JOptionPane.YES_OPTION) {
          registrarServicioDestajero();
          limpiardetalle();
          LimpiarTable();
           ListarServicio();
       }

    }//GEN-LAST:event_btngrabarActionPerformed

    private void btnbuscardestajeroActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbuscardestajeroActionPerformed
        // TODO add your handling code here:

        FrmBuscarDestajero frmdesta = new FrmBuscarDestajero();
        frmdesta.setVisible(true);
    }//GEN-LAST:event_btnbuscardestajeroActionPerformed

    private void btnbuscarpedidoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnbuscarpedidoActionPerformed
        // TODO add your handling code here:
        
            FrmBuscarPedido frmped = new FrmBuscarPedido();
        frmped.setVisible(true);  
      
    }//GEN-LAST:event_btnbuscarpedidoActionPerformed

    private void txtbuscarpedidoKeyReleased(java.awt.event.KeyEvent evt) {//GEN-FIRST:event_txtbuscarpedidoKeyReleased
        // TODO add your handling code here:
     LimpiarTable();
     ListarServicio();
    }//GEN-LAST:event_txtbuscarpedidoKeyReleased

    private void jButton31ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton31ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_jButton31ActionPerformed
public void LimpiarTableDetalle() 
        {
        for (int i = 0; i < modelodet.getRowCount(); i++) {
            modelodet.removeRow(i);
            i = i - 1;
        }
    }
    private void tblservicioMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tblservicioMouseClicked
        // TODO add your handling code here:
     int fila = tblservicio.rowAtPoint(evt.getPoint());
        LimpiarTableDetalle();
        ListarServicioDetalle(tblservicio.getValueAt(fila, 0).toString());
        idservedit=tblservicio.getValueAt(fila, 0).toString();
        idservedesdit=tblservicio.getValueAt(fila, 3).toString();
        servedesdit=tblservicio.getValueAt(fila, 4).toString();
       cantidentreedit=tblservicio.getValueAt(fila, 7).toString();
       estado=tblservicio.getValueAt(fila, 10).toString();
       idpedidoedit=tblservicio.getValueAt(fila, 1).toString();
       
    }//GEN-LAST:event_tblservicioMouseClicked

    private void btnculminadoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnculminadoActionPerformed
        // TODO add your handling code here:
           int fila = tblservicio.getSelectedRow();
        if (fila == -1) {
        JOptionPane.showMessageDialog(null, "Por favor seleccione una fila", "ERROR", JOptionPane.ERROR_MESSAGE);
        }
        else 
        {
            
            if(estado=="Completado")
            {
               JOptionPane.showMessageDialog(null, "El Servicio ya esta Completado");
            }
            else
            {
                 FrmCalculoPagoDestajero frmcal= new FrmCalculoPagoDestajero();
                 frmcal.lblidservicio.setText(idservedit);
                 frmcal.txtiddestajero.setText(idservedesdit);
                 frmcal.txtdestajero.setText(servedesdit);
                 frmcal.lblidpedido.setText(idpedidoedit);
                 frmcal.setDato(idservedit);
                 frmcal.setVisible(true);     
            }
            
     
        }
       
//        frmcal.txtcantidadentregada.setText(cantidentreedit);
    }//GEN-LAST:event_btnculminadoActionPerformed

    private void btnactualizarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnactualizarActionPerformed
        // TODO add your handling code here:
        LimpiarTable();
        ListarServicio();
    }//GEN-LAST:event_btnactualizarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTable TblServicioDetalle;
    public static javax.swing.JButton btnactualizar;
    private javax.swing.JButton btnbuscardestajero;
    private javax.swing.JButton btnbuscarpedido;
    private javax.swing.JButton btnculminado;
    private javax.swing.JButton btngrabar;
    private javax.swing.JButton jButton30;
    private javax.swing.JButton jButton31;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel37;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JScrollPane jScrollPane5;
    private javax.swing.JScrollPane jScrollPane6;
    private javax.swing.JScrollPane jScrollPane7;
    public static javax.swing.JTextField lblidpedido;
    private javax.swing.JLabel lblidserviciodestajero;
    public static javax.swing.JLabel lbltotal;
    private com.toedter.calendar.JDateChooser mskfecha;
    private com.toedter.calendar.JDateChooser mskfechdevolucion;
    public static javax.swing.JTable tblDetalleProducto;
    private javax.swing.JTable tblservicio;
    private javax.swing.JTextField txtbuscarpedido;
    public static javax.swing.JLabel txtcantidadtotal;
    public static javax.swing.JTextField txtidserviciodestajero;
    public static javax.swing.JTextField txtpedido;
    public static javax.swing.JTextField txtserviciodestajero;
    // End of variables declaration//GEN-END:variables
}
